# -*- coding: utf-8 -*-
"""
Created on Sun Apr 26 23:45:55 2020

@author: 2019330026 Yun, Junhyuk
"""

#query2.py
import sqlite3

# db 생성
con = sqlite3.connect('./university.db')
cur= con.cursor()

#query
query='select t1.semester as semester, t1.year as year, ID from (select semester, year,count(ID) as cnt, ID from teaches group by year,semester,ID) as t1 inner join (select semester, year, max(cnt) as max_cnt from (select semester, year,count(ID) as cnt from teaches group by year,semester,ID) group by semester, year) as t2 on t1.cnt=t2.max_cnt and t1.semester=t2.semester and t1.year=t2.year'

# select
try:
    cur.execute(query)
    row=cur.fetchall()
    print('semester,year,ID')
    for tup in row:
        print(tup[0], ',', tup[1], ',', tup[2], sep='')
except sqlite3.Error as e:
    print("Command skipped: ", e)

# cusor와 connection 종료
con.commit()
cur.close()
con.close()
